import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.application.Platform;
import javafx.scene.layout.BorderPane;
import javafx.stage.StageStyle;
import javafx.scene.input.MouseEvent;



public class main extends Application {

    Stage window;
    Scene scene, vysledek, chyba;

    private double xOffset = 0;
    private double yOffset = 0;

    public static void main(String[] args) {

        launch(args);

    }

    class customHeader extends HBox {
        public customHeader() {
            Button zavritOkno = new Button("X");
            zavritOkno.getStyleClass().add("zavritOkno");
            zavritOkno.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    Platform.exit();
                }
            });
            this.getChildren().add(zavritOkno);
        }
    }

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        window.setTitle("CV1");

        window.initStyle(StageStyle.DECORATED);
        BorderPane borderPane = new BorderPane();
        ToolBar toolBar = new ToolBar();

        toolBar.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                xOffset = mouseEvent.getSceneX();
                yOffset = mouseEvent.getSceneY();
            }
        });
        toolBar.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                window.setX(mouseEvent.getScreenX() - xOffset);
                window.setY(mouseEvent.getScreenY() - yOffset);
            }
        });

        toolBar.getItems().add(new customHeader());
        toolBar.getStyleClass().add("toolBar");
        borderPane.setTop(toolBar);


        VBox layout3 = new VBox(20);
        layout3.setAlignment(Pos.CENTER);
        Label labelChyba = new Label("Vstup není kladné číslo");
        labelChyba.getStyleClass().add("labelChyba");
        Button buttonChyba = new Button("Zkusit znovu");
        buttonChyba.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                window.setScene(scene);
            }
        });
        buttonChyba.getStyleClass().add("buttonChyba");
        layout3.getChildren().addAll(labelChyba, buttonChyba);

        VBox layout1 = new VBox(10);
        layout1.setAlignment(Pos.CENTER);

        final TextField cisloInput = new TextField();
        cisloInput.setPromptText("Zadejte sekundy");
        cisloInput.getStyleClass().add("cisloInput");

        scene = new Scene(layout1, 450, 300);
        scene.getStylesheets().add("stylesheet.css");
        primaryStage.setScene(scene);
        primaryStage.show();

        Button input = new Button("PŘEVÉST");

        //Tady začíná sranda
        input.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String cisloStr = cisloInput.getText();
                try {
                    int cislo = Integer.parseUnsignedInt(cisloStr);
                    System.out.println("DEBUG: Zadany pocet sekund: " + cislo);

                    int hh = cislo / 3600;
                    int mm = (cislo % 3600) / 60;
                    int ss = (cislo % 3600) % 60;

                    VBox layout2 = new VBox();
                    layout2.setAlignment(Pos.CENTER);
                    Label labelVysledek = new Label(+ hh + ":" +  mm + ":" + ss);
                    labelVysledek.getStyleClass().add("labelVysledek");
                    Button buttonZpet = new Button("Zadat jinou hodnotu");
                    buttonZpet.getStyleClass().add("buttonChyba");
                    layout2.getChildren().addAll(labelVysledek, buttonZpet);

                    vysledek = new Scene(layout2, 450, 300);
                    vysledek.getStylesheets().add("stylesheet.css");

                    window.setScene(vysledek);

                    buttonZpet.setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent actionEvent) {
                            window.setScene(scene);
                        }
                    });

                } catch (NumberFormatException e) {
                    window.setScene(chyba);
                }



            }
        });
        input.getStyleClass().add("input");
        layout1.getChildren().addAll(cisloInput, input);

        chyba = new Scene(layout3, 450, 300);
        chyba.getStylesheets().add("stylesheet.css");
    }

}
