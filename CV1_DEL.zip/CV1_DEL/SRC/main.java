import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.application.Platform;
import javafx.scene.layout.BorderPane;
import javafx.stage.StageStyle;
import javafx.scene.input.MouseEvent;


public class main extends Application {

    Stage window;
    Scene scene, vysledek;

    private double xOffset = 0;
    private double yOffset = 0;

    public static void main(String[] args) {

        launch(args);

    }

    class customHeader extends HBox {
        public customHeader() {
            Button zavritOkno = new Button("X");
            zavritOkno.getStyleClass().add("zavritOkno");
            zavritOkno.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    Platform.exit();
                }
            });
            this.getChildren().add(zavritOkno);
        }
    }

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;

        window.initStyle(StageStyle.UNDECORATED);
        BorderPane borderPane = new BorderPane();
        ToolBar toolBar = new ToolBar();

        toolBar.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                xOffset = mouseEvent.getSceneX();
                yOffset = mouseEvent.getSceneY();
            }
        });
        toolBar.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                window.setX(mouseEvent.getScreenX() - xOffset);
                window.setY(mouseEvent.getScreenY() - yOffset);
            }
        });

        int vyska = 25;
        toolBar.setPrefHeight(vyska);
        toolBar.setMinHeight(vyska);
        toolBar.setMaxHeight(vyska);
        toolBar.getItems().add(new customHeader());
        borderPane.setTop(toolBar);

        StackPane layout2 = new StackPane();
        Label labelVysledek = new Label("foo");
        labelVysledek.getStyleClass().add("labelVysledek");
        layout2.getChildren().addAll(toolBar, borderPane, labelVysledek);

        VBox layout1 = new VBox(10);
        Label label1 = new Label("Tohle je test");

        final TextField cisloInput = new TextField();
        cisloInput.getStyleClass().add("cisloInput");

        Button input = new Button("TEST");
        input.setOnAction(e -> window.setScene(vysledek));
        input.getStyleClass().add("input");
        layout1.getChildren().addAll(toolBar, borderPane, label1, cisloInput, input);

        scene = new Scene(layout1, 700, 500);
        scene.getStylesheets().add("stylesheet.css");
        primaryStage.setScene(scene);
        primaryStage.show();

        vysledek = new Scene(layout2, 700, 500);
        vysledek.getStylesheets().add("stylesheet.css");


        /*//Button 1
        Label label1 = new Label("Zadejte hodnotu v sekundách");
        Button button1 = new Button("Převést");
        button1.setOnAction(e -> window.setScene(scene2));

        //Layout 1 - children laid out in vertical column
        VBox layout1 = new VBox(20);
        layout1.getChildren().addAll(label1, button1);
        scene1 = new Scene(layout1, 500, 500);


        //Button 2
        Button button2 = new Button("Zadat jinou hodnotu");
        button2.setOnAction(e -> window.setScene(scene1));

        //Layout 2
        StackPane layout2 = new StackPane();
        layout2.getChildren().add(button2);
        scene2 = new Scene(layout2, 600, 300);

        //Display scene 1 at first
        window.setScene(scene1);
        window.setTitle("Převodník");
        window.show();*/
    }

}
